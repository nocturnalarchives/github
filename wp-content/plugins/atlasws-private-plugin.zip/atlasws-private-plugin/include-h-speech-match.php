<?

$hsppech_check = "/(?i)9-11|africa|bacon-haters|black|diversity|holocaust|islam|jesus|jew|lgbtq|notice-things|race|racial|racist|religous-group|shapiro|slavery|slave|splc|trans|zog/";

?>